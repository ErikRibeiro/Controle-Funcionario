<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "empresa";
$conexao = mysqli_connect($host,$user,$password,$database);
?>